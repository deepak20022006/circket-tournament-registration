package com.examly.springapp.service;

import org.springframework.stereotype.Service;
import com.examly.springapp.model.Notification;
import com.examly.springapp.model.Subscription;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.NotificationRepository;
import com.examly.springapp.repository.SubscriptionRepository;
import com.examly.springapp.repository.UserRepository;

import java.util.List;

@Service
public class NotificationService {

    private final NotificationRepository repo;
    private final UserRepository userRepo;
    private final SubscriptionRepository subscriptionRepo;

    public NotificationService(NotificationRepository repo,
            UserRepository userRepo,
            SubscriptionRepository subscriptionRepo) {
        this.repo = repo;
        this.userRepo = userRepo;
        this.subscriptionRepo = subscriptionRepo;
    }

    public List<Notification> getAll() {
        return repo.findAll();
    }

    public Notification create(Notification n) {
        return repo.save(n);
    }

    public List<Notification> getNotificationsForFan(Long fanId) {
        User user = userRepo.findById(fanId).orElseThrow(() -> new RuntimeException("User not found"));
        if (user.getRole() != User.Role.FAN)
            return List.of();

        List<Subscription> subs = subscriptionRepo.findByUserId(fanId);
        List<Long> teamIds = subs.stream().map(Subscription::getTeamId).toList();

        return repo.findAll().stream()
                .filter(n -> teamIds.contains(n.getTeam1Id()) || teamIds.contains(n.getTeam2Id()))
                .toList();
    }
}
