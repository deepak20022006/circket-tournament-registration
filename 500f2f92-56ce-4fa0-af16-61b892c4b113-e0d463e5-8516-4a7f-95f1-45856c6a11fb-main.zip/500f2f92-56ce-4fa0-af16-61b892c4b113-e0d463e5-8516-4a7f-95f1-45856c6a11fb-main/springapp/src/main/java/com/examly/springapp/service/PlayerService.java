package com.examly.springapp.service;

import java.util.List;
import java.util.Optional;

// import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.model.Player;
import com.examly.springapp.repository.PlayerRepo;

@Service
public class PlayerService {
    private PlayerRepo playerRepo;
    public PlayerService(PlayerRepo playerRepo)
    {
        this.playerRepo=playerRepo;
    }

    public Player addPlayer(Player player)
    {
        return playerRepo.save(player);
    }
    public List<Player> getAllPlayers()
    {
        return playerRepo.findAll();
    }
    public Player updatePlayer(int id, Player updatedPlayer)
    {
        Optional<Player> existing = playerRepo.findById(id);
        if(existing.isPresent())
        {
            Player player = existing.get();
            player.setPlayerName(updatedPlayer.getPlayerName());
            player.setPlayerCity(updatedPlayer.getPlayerCity());
            player.setPhone(updatedPlayer.getPhone());
            player.setPlayedIn(updatedPlayer.getPlayedIn());
            player.setPlayerType(updatedPlayer.getPlayerType());
            player.setLastPlayedFor(updatedPlayer.getLastPlayedFor());
            return playerRepo.save(player);
        }    else
        {
        return null;
        }
    }
    public String deletePlayer(int id)
    {
        if(playerRepo.existsById(id))
        {
            playerRepo.deleteById(id);
            return "Player with ID: "+id+" deleted";
        }
        else{
            return "Player not found.";
        }
    }
}
