    package com.examly.springapp.model;

    import lombok.*;
    import javax.persistence.*;

    @Entity
    @Table(name = "user")
    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    public class User {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long userId;

        @Column(nullable = false, length = 100)
        private String name;

        @Column(unique = true, nullable = false, length = 100)
        private String email;

        @Column(nullable = false, length = 100)
        private String password;

        @Enumerated(EnumType.STRING)
        private Role role;

        public enum Role {
            ADMIN, ORGANISER, FAN, PLAYER
        }
    }