package com.examly.springapp.service;

import org.springframework.stereotype.Service;
import com.examly.springapp.model.Subscription;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.SubscriptionRepository;
import com.examly.springapp.repository.UserRepository;

import java.util.List;
import java.util.Optional;

@Service
public class SubscriptionService {

    private final SubscriptionRepository repo;
    private final UserRepository userRepo;

    public SubscriptionService(SubscriptionRepository repo, UserRepository userRepo) {
        this.repo = repo;
        this.userRepo = userRepo;
    }

    public List<Subscription> getAllSubscriptions() {
        return repo.findAll();
    }

    public Optional<Subscription> getSubscriptionById(Long id) {
        return repo.findById(id);
    }

    public Subscription createSubscription(Subscription s) {
        if (s.getUserId() == null || !userRepo.existsById(s.getUserId())) {
            throw new RuntimeException("User not found");
        }

        // ensure only FAN users can subscribe
        userRepo.findById(s.getUserId()).ifPresent(user -> {
            if (user.getRole() != User.Role.FAN) {
                throw new RuntimeException("Only fans can subscribe to teams");
            }
        });

        if (s.getTeamId() == null) {
            throw new RuntimeException("Subscription must include a teamId");
        }

        return repo.save(s);
    }

    public Subscription updateSubscription(Long id, Subscription input) {
        return repo.findById(id).map(existing -> {
            if (input.getUserId() != null && !userRepo.existsById(input.getUserId())) {
                throw new RuntimeException("User not found");
            }

            if (input.getTeamId() == null) {
                throw new RuntimeException("Subscription must include a teamId");
            }

            existing.setUserId(input.getUserId());
            existing.setTeamId(input.getTeamId());

            return repo.save(existing);
        }).orElse(null);
    }

    public void deleteSubscription(Long id) {
        repo.deleteById(id);
    }

    public List<Subscription> findByUserId(Long userId) {
        return repo.findByUserId(userId);
    }

    public List<Subscription> findByTeamId(Long teamId) {
        return repo.findByTeamId(teamId);
    }
}
