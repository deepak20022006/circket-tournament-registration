package com.examly.springapp.model;

import javax.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "matches")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Match {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long matchId;

    private String matchName;

    // private Long organiserId;

    private LocalDateTime startDate;

    private LocalDateTime endDate;

    private Long team1Id;

    private Long team2Id;

    @Enumerated(EnumType.STRING)
    private MatchStatus status;

    public enum MatchStatus {
        SCHEDULED, LIVE, COMPLETED
    }

    private int scoreARuns = 0;
    private int scoreAWickets = 0;
    private int scoreBRuns = 0;
    private int scoreBWickets = 0;

    private Long winnerTeamId;

    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;

    // @ManyToOne(fetch = FetchType.LAZY)
    // @JoinColumn(name = "organiserId", insertable = false, updatable = false)
    // @JsonIgnore
    // private User organiser;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "team1Id", insertable = false, updatable = false)
    @JsonIgnore
    private Team team1;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "team2Id", insertable = false, updatable = false)
    @JsonIgnore
    private Team team2;
}
