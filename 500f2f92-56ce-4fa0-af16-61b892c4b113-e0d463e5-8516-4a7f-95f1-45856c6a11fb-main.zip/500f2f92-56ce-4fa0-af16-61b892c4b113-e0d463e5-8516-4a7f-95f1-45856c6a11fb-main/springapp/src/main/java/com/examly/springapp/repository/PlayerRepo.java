package com.examly.springapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.examly.springapp.model.Player;

public interface PlayerRepo extends JpaRepository<Player,Integer>{
    
    
}
