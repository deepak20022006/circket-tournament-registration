package com.examly.springapp.controller;

import org.springframework.web.bind.annotation.*;
import com.examly.springapp.model.Subscription;
import com.examly.springapp.service.SubscriptionService;

import java.util.List;

@RestController
@RequestMapping("/subscriptions")
@CrossOrigin(origins="*")
public class SubscriptionController {

    private final SubscriptionService service;

    public SubscriptionController(SubscriptionService service) {
        this.service = service;
    }

    @GetMapping
    public List<Subscription> all() {
        return service.getAllSubscriptions();
    }

    @GetMapping("/{id}")
    public Subscription getById(@PathVariable Long id) {
        return service.getSubscriptionById(id).orElse(null);
    }

    @PostMapping
    public Subscription create(@RequestBody Subscription subscription) {
        return service.createSubscription(subscription);
    }

    @PutMapping("/{id}")
    public Subscription update(@PathVariable Long id, @RequestBody Subscription subscription) {
        return service.updateSubscription(id, subscription);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.deleteSubscription(id);
    }

    @GetMapping("/user/{userId}")
    public List<Subscription> byUser(@PathVariable Long userId) {
        return service.findByUserId(userId);
    }

    @GetMapping("/team/{teamId}")
    public List<Subscription> byTeam(@PathVariable Long teamId) {
        return service.findByTeamId(teamId);
    }
}
