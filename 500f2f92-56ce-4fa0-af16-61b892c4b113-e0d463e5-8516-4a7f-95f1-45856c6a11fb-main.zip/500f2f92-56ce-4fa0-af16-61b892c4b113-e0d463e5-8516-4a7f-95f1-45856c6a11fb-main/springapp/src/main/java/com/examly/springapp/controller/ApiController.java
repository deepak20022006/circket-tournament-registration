package com.examly.springapp.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
// import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.model.Player;
import com.examly.springapp.service.PlayerService;

@RestController
@CrossOrigin(origins="*")
public class ApiController {
    private PlayerService playerService;
    public ApiController(PlayerService playerService)
    {
        this.playerService = playerService;
    }

    @PostMapping("/addPlayer")
    public ResponseEntity<String> addPlayer(@RequestBody Player player)
    {
        try{
            playerService.addPlayer(player);
            return ResponseEntity.ok("Player Added Succcessfully!");
        }
        catch (Exception e)
        {
            return ResponseEntity.status(500).body("Error adding player");
        } 
    }
    @GetMapping("/getAllPlayer")
    public ResponseEntity<List<Player>> getAllPlayers()
    {
        try{
            List<Player> players = playerService.getAllPlayers();
            return ResponseEntity.ok(players);
        }
        catch(Exception e)
        {
            return ResponseEntity.status(500).build();
        }
    }
    @PutMapping("updatePlayer/{id}")
    public ResponseEntity<String> updatePlayer(@PathVariable int id, @RequestBody Player updatedPlayer)
    {
        try{
            Player player = playerService.updatePlayer(id,updatedPlayer);
            if(player!=null)
            {
                return ResponseEntity.ok("Player updated successfully");
            }
            else
            {
                return ResponseEntity.status(404).body("Player not found");
            }
        }
        catch(Exception e)
        {
            return ResponseEntity.status(500).body("Error updating player");
        }
    }
    @DeleteMapping("deletePlayer/{id}")
    public ResponseEntity<String> deletePlayer(@PathVariable int id)
    {
        try{
            String res = playerService.deletePlayer(id);
            return ResponseEntity.ok(res);
        }
        catch(Exception e)
        {
            return ResponseEntity.status(500).body("Error deleting player");
        }

    }
}
