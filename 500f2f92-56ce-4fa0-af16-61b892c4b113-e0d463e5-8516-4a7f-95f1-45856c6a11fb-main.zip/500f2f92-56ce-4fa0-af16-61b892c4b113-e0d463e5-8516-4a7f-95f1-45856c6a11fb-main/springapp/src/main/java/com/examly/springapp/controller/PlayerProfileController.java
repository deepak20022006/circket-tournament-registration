package com.examly.springapp.controller;

import org.springframework.web.bind.annotation.*;
import com.examly.springapp.model.PlayerProfile;
import com.examly.springapp.service.PlayerProfileService;

import java.util.List;

@RestController
@RequestMapping("/players")
public class PlayerProfileController {

    private final PlayerProfileService service;

    public PlayerProfileController(PlayerProfileService service) {
        this.service = service;
    }

    @GetMapping
    public List<PlayerProfile> all() {
        return service.getAll();
    }

    @GetMapping("/{id}")
    public PlayerProfile getById(@PathVariable Long id) {
        return service.getById(id).orElse(null);
    }

    // Create: send flat JSON with userId and teamId fields (no nested user/team)
    @PostMapping
    public PlayerProfile create(@RequestBody PlayerProfile profile) {
        return service.create(profile);
    }

    // Update: load existing, change allowed fields, validate refs
    @PutMapping("/{id}")
    public PlayerProfile update(@PathVariable Long id, @RequestBody PlayerProfile profile) {
        return service.update(id, profile);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }

    @GetMapping("/user/{userId}")
    public List<PlayerProfile> byUser(@PathVariable Long userId) {
        return service.findByUserId(userId);
    }

    @GetMapping("/team/{teamId}")
    public List<PlayerProfile> byTeam(@PathVariable Long teamId) {
        return service.findByTeamId(teamId);
    }

    @GetMapping("/status/{status}")
    public List<PlayerProfile> byStatus(@PathVariable PlayerProfile.ApprovalStatus status) {
        return service.findByApprovalStatus(status);
    }
}
