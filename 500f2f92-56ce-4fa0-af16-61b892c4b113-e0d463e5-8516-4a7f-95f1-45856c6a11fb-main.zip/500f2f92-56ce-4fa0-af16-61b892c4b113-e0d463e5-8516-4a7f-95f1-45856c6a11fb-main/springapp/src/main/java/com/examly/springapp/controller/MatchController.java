package com.examly.springapp.controller;

import org.springframework.web.bind.annotation.*;
import com.examly.springapp.model.Match;
import com.examly.springapp.service.MatchService;

import java.util.List;

@RestController
@RequestMapping("/matches")
@CrossOrigin(origins="*")
public class MatchController {

    private final MatchService service;

    public MatchController(MatchService service) {
        this.service = service;
    }

    @GetMapping
    public List<Match> all() {
        return service.getAll();
    }

    @GetMapping("/{id}")
    public Match getById(@PathVariable Long id) {
        return service.getById(id).orElse(null);
    }

    // POST expects a flat payload with organiserId, team1Id, team2Id fields
    @PostMapping
    public Match create(@RequestBody Match match) {
        return service.create(match);
    }

    // Proper update: load existing, change fields, validate reference IDs, save
    @PutMapping("/{id}")
    public Match update(@PathVariable Long id, @RequestBody Match match) {
        return service.update(id, match);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
    @GetMapping("/status/{status}")
    public List<Match> byStatus(@PathVariable Match.MatchStatus status) {
        return service.findByStatus(status);
    }
}
