    package com.examly.springapp.service;

    import org.springframework.stereotype.Service;
    import com.examly.springapp.model.User;
    import com.examly.springapp.repository.UserRepository;

    import java.util.List;
    import java.util.Optional;

    @Service
    public class UserService {

        private final UserRepository repo;

        public UserService(UserRepository repo) {
            this.repo = repo;
        }

        public List<User> getAllUsers() {
            return repo.findAll();
        }

        public Optional<User> getUserById(Long id) {
            return repo.findById(id);
        }

        public User createUser(User user) {
            return repo.save(user);
        }

        public User updateUser(Long id, User input) {
            return repo.findById(id).map(existing -> {
                existing.setName(input.getName());
                existing.setEmail(input.getEmail());
                existing.setPassword(input.getPassword());
                existing.setRole(input.getRole());
                return repo.save(existing);
            }).orElse(null);
        }

        public void deleteUser(Long id) {
            repo.deleteById(id);
        }
    }
