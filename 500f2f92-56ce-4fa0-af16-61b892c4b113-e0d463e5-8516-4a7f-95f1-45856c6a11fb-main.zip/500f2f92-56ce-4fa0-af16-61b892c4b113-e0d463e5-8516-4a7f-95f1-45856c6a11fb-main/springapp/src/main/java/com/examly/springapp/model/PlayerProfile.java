package com.examly.springapp.model;

import lombok.*;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "playerProfile")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PlayerProfile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long playerId;

    private String playerName;
    private String playerCity;
    private String phone;

    @Enumerated(EnumType.STRING)
    private PlayerType playerType;

    private String lastPlayedFor;

    private Long userId;
    private Long teamId;

    @Enumerated(EnumType.STRING)
    private ApprovalStatus approvalStatus = ApprovalStatus.PENDING;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userId", insertable = false, updatable = false)
    @JsonIgnore
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "teamId", insertable = false, updatable = false)
    @JsonIgnore
    private Team team;

    public enum PlayerType {
        BATSMAN, BOWLER, ALL_ROUNDER, WICKET_KEEPER
    }

    public enum ApprovalStatus {
        PENDING, REJECTED, APPROVED
    }
}