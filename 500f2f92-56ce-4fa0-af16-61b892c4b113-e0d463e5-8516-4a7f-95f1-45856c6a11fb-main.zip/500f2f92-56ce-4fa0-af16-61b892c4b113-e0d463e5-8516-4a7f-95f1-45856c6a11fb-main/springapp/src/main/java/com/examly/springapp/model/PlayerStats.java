package com.examly.springapp.model;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.*;

@Entity
@Table(name = "player_stats")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PlayerStats {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long playerId;

    private int matchesPlayed = 0;
    private int totalRuns = 0;
    private int totalWickets = 0;
    private int oversBowled = 0;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "playerId", insertable = false, updatable = false)
    @JsonIgnore
    private PlayerProfile player;

    public PlayerStats(Long playerId) {
        this.playerId = playerId;
    }
}