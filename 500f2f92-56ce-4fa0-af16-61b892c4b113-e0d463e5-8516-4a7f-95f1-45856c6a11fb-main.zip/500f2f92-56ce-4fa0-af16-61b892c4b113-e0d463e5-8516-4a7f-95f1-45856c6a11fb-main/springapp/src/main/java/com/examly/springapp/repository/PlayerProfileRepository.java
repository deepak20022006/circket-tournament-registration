package com.examly.springapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.examly.springapp.model.PlayerProfile;
import java.util.List;

@Repository
public interface PlayerProfileRepository extends JpaRepository<PlayerProfile, Long> {
    List<PlayerProfile> findByUserId(Long userId);

    List<PlayerProfile> findByTeamId(Long teamId);

    List<PlayerProfile> findByApprovalStatus(PlayerProfile.ApprovalStatus status);
}
