package com.examly.springapp.controller;

import org.springframework.web.bind.annotation.*;
import com.examly.springapp.model.Team;
import com.examly.springapp.service.TeamService;

import java.util.List;

@RestController
@RequestMapping("/teams")
@CrossOrigin(origins="*")
public class TeamController {

    private final TeamService service;

    public TeamController(TeamService service) {
        this.service = service;
    }

    @GetMapping
    public List<Team> all() {
        return service.getAllTeams();
    }

    @GetMapping("/{id}")
    public Team getById(@PathVariable Long id) {
        return service.getTeamById(id).orElse(null);
    }

    @PostMapping
    public Team create(@RequestBody Team team) {
        return service.createTeam(team);
    }

    @PutMapping("/{id}")
    public Team update(@PathVariable Long id, @RequestBody Team team) {
        return service.updateTeam(id, team);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.deleteTeam(id);
    }
}
