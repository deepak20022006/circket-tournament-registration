package com.examly.springapp.model;

import lombok.*;
import javax.persistence.*;

@Entity
@Table(name = "team")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Team {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long team_id;

    @Column(nullable = false, length = 100)
    private String teamName;

    private String city;
}
