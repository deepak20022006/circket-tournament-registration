    package com.examly.springapp.model;

    import lombok.*;

    import java.time.LocalDateTime;

    import javax.persistence.*;

    import org.hibernate.annotations.CreationTimestamp;

    import com.fasterxml.jackson.annotation.JsonIgnore;

    @Entity
    @Table(name = "notification")
    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    public class Notification {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long notificationId;

        private Long team1Id;
        private Long team2Id;
        private Long userId;

        @Column(nullable = false)
        private String message;

        @Enumerated(EnumType.STRING)
        private NotificationType type;

        public enum NotificationType {
            WICKET_FALL, MATCH_RESULT, MATCH_DAY;
        }

        @CreationTimestamp
        @Column(nullable = false, updatable = false)
        private LocalDateTime createdAt;

        @ManyToOne(fetch = FetchType.LAZY)
        @JoinColumn(name = "userId", insertable = false, updatable = false)
        @JsonIgnore
        private User user;
    }