package com.examly.springapp.controller;

import org.springframework.web.bind.annotation.*;
import com.examly.springapp.model.Notification;
import com.examly.springapp.service.NotificationService;

import java.util.List;

@RestController
@RequestMapping("/notifications")
@CrossOrigin(origins="*")
public class NotificationController {

    private final NotificationService service;

    public NotificationController(NotificationService service) {
        this.service = service;
    }

    @GetMapping
    public List<Notification> all() {
        return service.getAll();
    }

    @GetMapping("/fan/{fanId}")
    public List<Notification> fanNotifications(@PathVariable Long fanId) {
        return service.getNotificationsForFan(fanId);
    }
}
