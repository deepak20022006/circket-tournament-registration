package com.examly.springapp.controller;

import org.springframework.web.bind.annotation.*;
import com.examly.springapp.model.PlayerStats;
import com.examly.springapp.service.PlayerStatsService;

import java.util.List;

@RestController
@RequestMapping("/player-stats")
public class PlayerStatsController {

    private final PlayerStatsService service;

    public PlayerStatsController(PlayerStatsService service) {
        this.service = service;
    }

    @GetMapping
    public List<PlayerStats> all() {
        return service.getAll();
    }

    @GetMapping("/{id}")
    public PlayerStats getById(@PathVariable Long id) {
        return service.getById(id).orElse(null);
    }

    @GetMapping("/player/{playerId}")
    public PlayerStats byPlayerId(@PathVariable Long playerId) {
        return service.getByPlayerId(playerId).orElse(null);
    }

    @PostMapping
    public PlayerStats create(@RequestBody PlayerStats stats) {
        return service.create(stats);
    }

    @PutMapping("/{id}")
    public PlayerStats update(@PathVariable Long id, @RequestBody PlayerStats stats) {
        return service.update(id, stats);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
