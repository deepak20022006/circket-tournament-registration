package com.examly.springapp.service;

import org.springframework.stereotype.Service;
import com.examly.springapp.model.Team;
import com.examly.springapp.repository.TeamRepository;

import java.util.List;
import java.util.Optional;

@Service
public class TeamService {

    private final TeamRepository repo;

    public TeamService(TeamRepository repo) {
        this.repo = repo;
    }

    public List<Team> getAllTeams() {
        return repo.findAll();
    }

    public Optional<Team> getTeamById(Long id) {
        return repo.findById(id);
    }

    public Team createTeam(Team team) {
        return repo.save(team);
    }

    public Team updateTeam(Long id, Team input) {
        return repo.findById(id).map(existing -> {
            existing.setTeamName(input.getTeamName());
            existing.setCity(input.getCity());
            return repo.save(existing);
        }).orElse(null);
    }

    public void deleteTeam(Long id) {
        repo.deleteById(id);
    }
}
