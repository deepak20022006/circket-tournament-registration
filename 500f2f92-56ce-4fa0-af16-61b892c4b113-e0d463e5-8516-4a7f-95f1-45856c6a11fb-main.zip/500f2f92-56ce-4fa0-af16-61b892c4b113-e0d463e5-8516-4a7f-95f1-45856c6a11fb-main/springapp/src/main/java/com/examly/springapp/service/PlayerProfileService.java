package com.examly.springapp.service;

import org.springframework.stereotype.Service;
import com.examly.springapp.model.PlayerProfile;
import com.examly.springapp.repository.PlayerProfileRepository;
import com.examly.springapp.repository.UserRepository;
import com.examly.springapp.repository.TeamRepository;

import java.util.List;
import java.util.Optional;

@Service
public class PlayerProfileService {

    private final PlayerProfileRepository repo;
    private final UserRepository userRepo;
    private final TeamRepository teamRepo;

    public PlayerProfileService(PlayerProfileRepository repo, UserRepository userRepo, TeamRepository teamRepo) {
        this.repo = repo;
        this.userRepo = userRepo;
        this.teamRepo = teamRepo;
    }

    public List<PlayerProfile> getAll() {
        return repo.findAll();
    }

    public Optional<PlayerProfile> getById(Long id) {
        return repo.findById(id);
    }

    public PlayerProfile create(PlayerProfile profile) {
        if (profile.getUserId() == null || !userRepo.existsById(profile.getUserId()))
            throw new RuntimeException("User not found");
        if (profile.getTeamId() != null && !teamRepo.existsById(profile.getTeamId()))
            throw new RuntimeException("Team not found");
        return repo.save(profile);
    }

    public PlayerProfile update(Long id, PlayerProfile input) {
        return repo.findById(id).map(existing -> {
            // update simple fields
            existing.setPlayerName(input.getPlayerName());
            existing.setPlayerCity(input.getPlayerCity());
            existing.setPhone(input.getPhone());
            existing.setPlayerType(input.getPlayerType());
            existing.setLastPlayedFor(input.getLastPlayedFor());
            // validate and update references
            if (input.getUserId() != null && !userRepo.existsById(input.getUserId()))
                throw new RuntimeException("User not found");
            existing.setUserId(input.getUserId());
            if (input.getTeamId() != null && !teamRepo.existsById(input.getTeamId()))
                throw new RuntimeException("Team not found");
            existing.setTeamId(input.getTeamId());
            existing.setApprovalStatus(input.getApprovalStatus());
            return repo.save(existing);
        }).orElse(null);
    }

    public void delete(Long id) {
        repo.deleteById(id);
    }

    public List<PlayerProfile> findByUserId(Long userId) {
        return repo.findByUserId(userId);
    }

    public List<PlayerProfile> findByTeamId(Long teamId) {
        return repo.findByTeamId(teamId);
    }

    public List<PlayerProfile> findByApprovalStatus(PlayerProfile.ApprovalStatus status) {
        return repo.findByApprovalStatus(status);
    }
}
