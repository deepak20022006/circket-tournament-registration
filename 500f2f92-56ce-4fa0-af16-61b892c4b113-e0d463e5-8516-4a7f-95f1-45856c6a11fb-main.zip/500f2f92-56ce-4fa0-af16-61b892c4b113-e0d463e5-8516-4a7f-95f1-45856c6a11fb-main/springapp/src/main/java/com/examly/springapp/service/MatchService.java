package com.examly.springapp.service;

import org.springframework.stereotype.Service;
import com.examly.springapp.model.Match;
import com.examly.springapp.model.Notification;
import com.examly.springapp.repository.MatchRepository;
import com.examly.springapp.repository.TeamRepository;

import java.util.List;
import java.util.Optional;

@Service
public class MatchService {

    private final MatchRepository repo;
    private final TeamRepository teamRepo;
    private final NotificationService notificationService;

    public MatchService(MatchRepository repo,
            TeamRepository teamRepo,
            NotificationService notificationService) {
        this.repo = repo;
        this.teamRepo = teamRepo;
        this.notificationService = notificationService;
    }

    public List<Match> getAll() {
        return repo.findAll();
    }

    public Optional<Match> getById(Long id) {
        return repo.findById(id);
    }

    public Match create(Match m) {
        if (m.getTeam1Id() == null || !teamRepo.existsById(m.getTeam1Id()))
            throw new RuntimeException("Team1 not found");
        if (m.getTeam2Id() == null || !teamRepo.existsById(m.getTeam2Id()))
            throw new RuntimeException("Team2 not found");

        m.setScoreARuns(0);
        m.setScoreAWickets(0);
        m.setScoreBRuns(0);
        m.setScoreBWickets(0);
        m.setWinnerTeamId(null);
        m.setStatus(Match.MatchStatus.SCHEDULED);

        Match saved = repo.save(m);

        // Global notification
        createGlobalNotification(saved, Notification.NotificationType.MATCH_DAY,
                "Match scheduled: " + saved.getMatchName());

        return saved;
    }

    public Match update(Long id, Match input) {
        return repo.findById(id).map(existing -> {

            boolean wicketFell = input.getScoreAWickets() > existing.getScoreAWickets()
                    || input.getScoreBWickets() > existing.getScoreBWickets();
            boolean statusChanged = existing.getStatus() != input.getStatus();

            existing.setMatchName(input.getMatchName());
            existing.setStartDate(input.getStartDate());
            existing.setEndDate(input.getEndDate());
            existing.setTeam1Id(input.getTeam1Id());
            existing.setTeam2Id(input.getTeam2Id());
            existing.setScoreARuns(input.getScoreARuns());
            existing.setScoreAWickets(input.getScoreAWickets());
            existing.setScoreBRuns(input.getScoreBRuns());
            existing.setScoreBWickets(input.getScoreBWickets());
            existing.setStatus(input.getStatus());

            if (existing.getStatus() == Match.MatchStatus.COMPLETED) {
                if (existing.getScoreARuns() > existing.getScoreBRuns()) {
                    existing.setWinnerTeamId(existing.getTeam1Id());
                } else if (existing.getScoreBRuns() > existing.getScoreARuns()) {
                    existing.setWinnerTeamId(existing.getTeam2Id());
                } else {
                    existing.setWinnerTeamId(null);
                }
            }

            Match saved = repo.save(existing);

            // Global notifications
            if (wicketFell) {
                createGlobalNotification(saved, Notification.NotificationType.WICKET_FALL,
                        "Wicket fell in match: " + saved.getMatchName());
            }

            if (statusChanged && saved.getStatus() == Match.MatchStatus.LIVE) {
                createGlobalNotification(saved, Notification.NotificationType.MATCH_DAY,
                        "Match is now LIVE: " + saved.getMatchName());
            }

            if (statusChanged && saved.getStatus() == Match.MatchStatus.COMPLETED) {
                String msg;
                if (saved.getWinnerTeamId() != null) {
                    String winnerTeamName = teamRepo.findById(saved.getWinnerTeamId())
                            .map(team -> team.getTeamName())
                            .orElse("Unknown Team");
                    msg = "Match completed! Winner: " + winnerTeamName;
                } else {
                    msg = "Match completed! It’s a draw.";
                }
                createGlobalNotification(saved, Notification.NotificationType.MATCH_RESULT, msg);
            }

            return saved;
        }).orElse(null);

    }

    private void createGlobalNotification(Match match, Notification.NotificationType type, String message) {
        Notification n = new Notification();
        n.setTeam1Id(match.getTeam1Id());
        n.setTeam2Id(match.getTeam2Id());
        n.setType(type);
        n.setMessage(message);
        notificationService.create(n);
    }

    public void delete(Long id) {
        repo.deleteById(id);
    }

    public List<Match> findByStatus(Match.MatchStatus status) {
        return repo.findByStatus(status);
    }
}