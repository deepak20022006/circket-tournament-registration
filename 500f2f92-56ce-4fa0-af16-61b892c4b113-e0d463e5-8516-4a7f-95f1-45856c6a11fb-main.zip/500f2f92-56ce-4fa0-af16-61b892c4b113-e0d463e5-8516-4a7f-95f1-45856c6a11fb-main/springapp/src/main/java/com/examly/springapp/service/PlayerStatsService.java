package com.examly.springapp.service;

import org.springframework.stereotype.Service;
import com.examly.springapp.model.PlayerStats;
import com.examly.springapp.repository.PlayerStatsRepository;
import com.examly.springapp.repository.PlayerProfileRepository;

import java.util.List;
import java.util.Optional;

@Service
public class PlayerStatsService {

    private final PlayerStatsRepository repo;
    private final PlayerProfileRepository playerRepo;

    public PlayerStatsService(PlayerStatsRepository repo, PlayerProfileRepository playerRepo) {
        this.repo = repo;
        this.playerRepo = playerRepo;
    }

    public List<PlayerStats> getAll() {
        return repo.findAll();
    }

    public Optional<PlayerStats> getById(Long id) {
        return repo.findById(id);
    }

    public Optional<PlayerStats> getByPlayerId(Long playerId) {
        return repo.findByPlayerId(playerId);
    }

    public PlayerStats create(PlayerStats stats) {
        if (stats.getPlayerId() == null || !playerRepo.existsById(stats.getPlayerId()))
            throw new RuntimeException("Player not found");
        return repo.save(stats);
    }

    public PlayerStats update(Long id, PlayerStats input) {
        return repo.findById(id).map(existing -> {
            if (input.getPlayerId() != null && !playerRepo.existsById(input.getPlayerId()))
                throw new RuntimeException("Player not found");
            existing.setPlayerId(input.getPlayerId());
            existing.setMatchesPlayed(input.getMatchesPlayed());
            existing.setTotalRuns(input.getTotalRuns());
            existing.setTotalWickets(input.getTotalWickets());
            existing.setOversBowled(input.getOversBowled());
            return repo.save(existing);
        }).orElse(null);
    }

    public void delete(Long id) {
        repo.deleteById(id);
    }
}
